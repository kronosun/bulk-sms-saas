
<?php $__env->startSection('title', 'Create Contact'); ?>
<?php $__env->startSection('content'); ?>

<div class="main-container">
	<?php echo $__env->make('layouts.shared.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		<div class="pd-ltr-20 xs-pd-20-10">
			<div class="min-height-200px">
				<div class="page-header">
					<div class="row">
						<div class="col-md-6 col-sm-12">
							<div class="title">
								<h4>Contact List</h4>
							</div>
							<nav aria-label="breadcrumb" role="navigation">
								<ol class="breadcrumb">
									<li class="breadcrumb-item"><a href="index.html">Home</a></li>
									<li class="breadcrumb-item active" aria-current="page">Contacts</li>
								</ol>
							</nav>
						</div>
						
					</div>
				</div>
				<!-- Checkbox select Datatable start -->
				<div class="card-box mb-30">
					<div class="pd-20">
						<h4 class="text-blue h4">My Contacts</h4>
					</div>
					<div class="pb-20">
						<table class="checkbox-datatable table nowrap">
							<thead>

								<tr>
									<th><div class="dt-checkbox">
											<input type="checkbox" name="select_all" value="1" id="example-select-all">
											<span class="dt-checkbox-label"></span>
										</div>
									</th>
									<th>S/N</th>
									<th>Title</th>
									<th>Numbers</th>
									<th>Created</th>
									<th>Last Updated</th>
									<th>Action</th> 
								</tr>
							</thead>
							<tbody>
								<?php $count = 0; ?>
								<?php $__currentLoopData = $contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<?php $count ++ ?>
								<tr>
									<td></td>
									<td><?php echo e($count); ?></td>
									<td><?php echo e($contact->title); ?></td>
									<td><?php echo e(number_format(count(explode(',', $contact->numbers)))); ?></td>
									<td><?php echo e(date('d.m.Y', strtotime($contact->created_at))); ?></td>
									<td><?php echo e(date('d.m.Y', strtotime($contact->updated_at))); ?></td>
									<td>
										<a href="<?php echo e(route('contact-detail', $contact->slug)); ?>" class="btn btn-secondary btn-sm">View <i class="fa fa-eye"></i></a>
										
										<button class="btn btn-danger btn-sm" data-toggle="modal" data-target="#delete-<?php echo e($contact->slug); ?>">Delete <i class="fa fa-trash"></i></button>
									</td> 
								</tr>

								<!--Edit Modal -->
									<div class="modal fade" id="delete-<?php echo e($contact->slug); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
									  <div class="modal-dialog modal-dialog-centered" role="document">
									    <div class="modal-content">
									    	<form action="<?php echo e(route('delete-contact')); ?>" method="post">
									    		<?php echo csrf_field(); ?>
											      <div class="modal-heade pt-3 row pr-1">
											      	<div class="col-11">
											      		<h6 class="text-center modal-title">Confirm action</h6>
											      	</div>
											      	<div class="col-1 text-left">
												      	<button type="button" class="close" data-dismiss="modal" aria-label="Close">
												          <span aria-hidden="true">&times;</span>
												        </button>
											      	</div>
											        

											        
											      </div>
											      <hr>
											      <div class="modal-bod text-center">
											      	Delete <?php echo e($contact->title); ?>?
											        	<input type="hidden" name="contact_slug" value="<?php echo e($contact->slug); ?>">
											        	
											      </div>
											      <hr>
											      <div class="modal-foote text-center py-3">
											        <button type="button" class="btn btn-secondary" data-dismiss="modal"><i class="fa fa-arrow-left"></i> Go back</button>
											        <button type="" class="btn btn-primary">Proceed >></button>
											      </div>
									      	</form>
									    </div>
									  </div>
									</div>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								
							</tbody>
						</table>
					</div>
				</div>

				
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sk\resources\views/contacts/list.blade.php ENDPATH**/ ?>