
<?php $__env->startSection('title', 'Create Contact'); ?>
<?php $__env->startSection('content'); ?>

<div class="main-container">
	
		<div class="pd-ltr-20 xs-pd-20-10">
			<div class="min-height-200px">
				<div class="page-header">
					<div class="row">
						<div class="col-md-6 col-sm-12">
							<div class="title">
								<h4>Scheduled Messages</h4>
							</div>
							<nav aria-label="breadcrumb" role="navigation">
								<ol class="breadcrumb">
									<li class="breadcrumb-item"><a href="index.html">Home</a></li>
									<li class="breadcrumb-item"><a href="index.html">Messages</a></li>
									<li class="breadcrumb-item active" aria-current="page">Scheduled</li>
								</ol>
							</nav>
						</div>
						
					</div>
				</div>
				 <?php echo $__env->make('layouts.shared.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
				<!-- Simple Datatable start -->
				<div class="card-box mb-30">
					<div class="pd-20">
						<h4 class="text-blue h4">Scheduled messages</h4>

					</div>
					<div class="pb-20">
						<table class="data-table table stripe hover nowrap">
							<thead>
								<tr>
									<th class="table-plus datatable-nosort">S/N</th>
									<th>Title</th>
									
									
									<th>Send Date/Time</th>
									<th>Status</th>
									<th>Action</th>
								</tr>
							</thead>
							<tbody>
								<?php $count = 0; ?>
								<?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<?php $contactArr = []; 
										// dd($message->messageStatus->color);
									?>

										<?php
										// $message->schedule()->first()->contact
											// foreach ($message->contacts as $key => $contact) {
												
											// 	array_push($contactArr, [$contact->slug=>$contact->title]);
											// }

											foreach($message->schedule as $schedule){
												$contactArr[$schedule->contact->slug] = $schedule->contact->title;
												// array_push($contactArr, [$schedule->contact->slug=>$schedule->contact->title]);
											}
											// dd($contactArr);
										?>
									<?php $count ++; ?>
									<tr id="row-<?php echo e($message->slug); ?>">
										<td class="table-plus"><?php echo e($count); ?></td>
										<td><?php echo e(substr($message->title, 0, 20)); ?> <?php echo e(strlen($message->title)>20?'...':''); ?></td>
										
										
										<td><?php if(!is_null($message->schedule()->first())): ?><?php echo e(date('d.m.Y, h:i a', $message->schedule()->first()->date)); ?><?php else: ?> N/A <?php endif; ?></td>
										<td><span class="badge badge-<?php echo e($message->messageStatus->color); ?>"><?php echo e($message->messageStatus->statement); ?></span></td>
										<td>
											<a href="javascript::void(0)" class="btn btn-secondary btn-sm"  data-toggle="modal" data-target="#view-<?php echo e($message->slug); ?>">View <i class="fa fa-eye"></i></a>
											<a href="<?php echo e(route('edit-message', $message->slug).'?action=modify_schedule'); ?>" class="btn btn-primary btn-sm">Edit <i class="fa fa-edit"></i></a>
											
											<?php if($message->messageStatus->number!='5'): ?>
											<button class="btn btn-danger btn-sm" type="button" id="delete-btn-<?php echo e($message->slug); ?>" slug="<?php echo e($message->slug); ?>">Cancel <i class="fa fa-power-off"></i></button>
											<?php endif; ?>
										</td> 
									</tr>

									<!--Edit Modal -->
									<div class="modal fade" id="view-<?php echo e($message->slug); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
									  <div class="modal-dialog modal-dialog-centered" role="document">
									    <div class="modal-content">
									    	
											<div class="modal-header pt-3 row pr-1">
												<div class="col-11">
													<h6 class="text-center modal-title"><?php echo e($message->title); ?></h6>
												</div>
												<div class="col-1 text-left">
											  		<button type="button" class="close" data-dismiss="modal" aria-label="Close">
											      		<span aria-hidden="true">&times;</span>
											    	</button>
												</div>



											</div>
											<div class="modal-body text-left">
												<div style="white-space: pre-wrap;"><?php echo e($message->content); ?></div>
												<hr>
												<div class="row">
													<div class="col-6 text-left">
														<small>Composed <?php echo e(date('d.m.Y', strtotime($message->created_at))); ?></small>
													</div>
													<div class="col-12">
														<hr>
														<h6>Contacts</h6>
														<hr>
														<?php $__currentLoopData = $contactArr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
															<a href="<?php echo e(route('contact-detail', $key)); ?>"><span class="badge badge-primary mr-1"><?php echo e($contact); ?></span></a>
														<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
													</div>
													<div class="col-6 text-left mt-3">
														<small>Status: <span class="badge badge-<?php echo e($message->messageStatus->color); ?>"><?php echo e($message->messageStatus->statement); ?></span></small>
													</div>
													
													
												</div>
											</div>
											<div class="modal-footer text-center py-3">
												<button type="button" class="btn btn-secondary" data-dismiss="modal"><i class="fa fa-arrow-left"></i> Go back</button>
											</div>
									    </div>
									  </div>
									</div>

									<!--Delete Modal -->


									<script>
										//A title with a text under
								        $('#delete-btn-<?php echo e($message->slug); ?>').click(function () {
								           let $this = $(this);
											let oldHtml = $this.html();
											let targetNumber= $this.attr('slug')
								            swal({
								                title: 'Cancel Schedule for <?php echo e($message->title); ?>?',
								                text: "You won't be able to revert this!",
								                icon: 'warning',
								                buttons: true,
								                // confirmButtonClass: 'btn btn-success',
								                // cancelButtonClass: 'btn btn-danger',
								                // confirmButtonText: 'Yes, delete it!',

								            }).then((proceed)=>{
								            	if (proceed) {
								            		$.ajax({
														type: 'POST',
														url: "<?php echo e(route('delete-schedule')); ?>",
														data: {
															message_id:"<?php echo e($message->id); ?>",
															_token: universal_token
														},
														success:function(response){
															$this.prop('disabled', false);
															$this.html(oldHtml);
															$('#delete-'+targetNumber).modal('hide');
															let feedback = JSON.parse(response);
															if (feedback.status=='success') {
																
																$('#row-'+targetNumber).remove();												
															}
															 swal({
													                title: feedback.status,
													                text: feedback.msg,
													                icon: feedback.alert,
													                
													                // confirmButtonClass: 'btn btn-success',
													                // cancelButtonClass: 'btn btn-danger',
													                // confirmButtonText: 'Yes, delete it!',

													            })
															// flashMessage(feedback.alert, feedback.msg)
															// alert('Contact Updated');
														},
														error:function(param1, param2, param3){
															alert(param3);
														}
													});
								            	}
								            })
								            	
								            	
								            	
								            	
								            	// $(document).find('.swal2-confirm').on('click', function(){
								            	// 	alert('confimred')
								            	// })
								            	
								                // swal(
								                //     'Deleted!',
								                //     'Your file has been deleted.',
								                //     'success'
								                // )
								            })
									        
								        // });
									</script>
									
												<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
											</tbody>
										</table>
									</div>
								</div>
				<!-- Simple Datatable End -->

					

					<script>

						$('.delete-msg-btn').on('click', function(){
							let $this = $(this);
							let oldHtml = $this.html();
							let targetNumber= $this.attr('slug')
							console.log(targetNumber)
							let formData = $('#form-'+targetNumber).serialize();

							$this.html('<i class="fa fa-spin fa-spinner"></i>');
							
							$this.prop('disabled', true);
							$.ajax({
								type: 'POST',
								url: "<?php echo e(route('delete-message')); ?>",
								data: formData,
								success:function(response){
									$this.prop('disabled', false);
									$this.html(oldHtml);
									$('#delete-'+targetNumber).modal('hide');
									let feedback = JSON.parse(response);
									if (feedback.status=='success') {
										$('#row-'+targetNumber).remove();												
									}
									flashMessage(feedback.alert, feedback.msg)
									// alert('Contact Updated');
								},
								error:function(param1, param2, param3){
									alert(param3);
								}
							});


						});


					</script>
				
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sk\resources\views/sms/scheduled.blade.php ENDPATH**/ ?>