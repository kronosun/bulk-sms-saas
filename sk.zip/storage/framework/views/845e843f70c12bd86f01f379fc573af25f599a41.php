
<?php $__env->startSection('title', 'Compose SMS'); ?>
<?php $__env->startSection('content'); ?>
	<div class="main-container">
		<div class="pd-ltr-20 xs-pd-20-10">
			<div class="min-height-200px">
				<div class="page-header">
					<div class="row">
						<div class="col-md-6 col-sm-12">
							<div class="title">
								<h4>Form</h4>
							</div>
							<nav aria-label="breadcrumb" role="navigation">
								<ol class="breadcrumb">
									<li class="breadcrumb-item"><a href="index.html">Home</a></li>	
									<li class="breadcrumb-item active" aria-current="page">Compose Message</li>
								</ol>
							</nav>
						</div>
					</div>
				</div>
				<!-- Default Basic Forms Start -->
				<div class="pd-20 card-box mb-30">
					<div class="clearfix">
						<div class="pull-left">
							<h4 class="text-blue h4">Write your message</h4>
							<p class="mb-30">Your message is saved automaticaly as you type</p>
						</div>
					
					</div>
					<form>
						<div class="form-group">
							<label class="col-form-label">Message Title</label>
								<input class="form-control" id="title" type="text" placeholder="Message title">
						</div>
						<div class="form-group">
							<label class=" col-form-label">Message Content</label>
							<textarea class="form-control" name="message" id="message-content" placeholder="start typing..."></textarea>
							
						</div>
						<div class="text-right">
							<small class="form-text text-muted"><span id="char-count">30</span> characters (<span id="page-count">1</span> page).</small>
						</div>
						<div class="row">
							<div class="form-group col-6">
								<label class="col-form-label">Send option</label>
								<select class="form-control" id="send-option">
									<option value="existing">Existing contacts</option>
									<option value="upload">Upload new contacts</option>
									<option value="manual_input">Manualy input contacts</option>
								</select>
							</div>

							<div class="col-6 form-group options" id="existing">
								<label class="col-form-label">Select Contacts Group</label>
								<select class="custom-select2 form-control" multiple="multiple" style="width: 100%;">
										
									<optgroup label="Mountain Time Zone">
										<option value="AZ">Ignite Network</option>
										<option value="CO">Ignite Inner circle</option>
										<option value="ID">Ignite Project Team</option>
										<option value="MT">My Classmates</option>
										<option value="NE">My Family</option>
									</optgroup>
								</select>
							</div>

							<div class="col-6 form-group options" id="upload">
								<label class="col-form-label">Upload new contact</label>
								<small>CSV files only</small>
								<input type="file" name="contact_upload" class="form-control">
							</div>

							<div class="col-6 form-group options" id="manual_input">
								<label class="col-form-label">Input Contacts</label>
								<small>separate each contact with a comma or space</small>
								<input type="text" name="contact_input" id="contact-input" class="form-control w-100" data-role="tagsinput">
							</div> 
							<div class="col-12 text-right">
								<a href="#" class="btn">Send later <i class="fa fa-calendar"></i></a>
								<button class="btn">Send now<i class="fa fa-paper-plane"></i></button>
							</div>
						</div>
					</form>
						
						
				</div>
			</div>
		</div>
				<!-- Input Validation End -->

	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sk\resources\views/sms/compose.blade.php ENDPATH**/ ?>