<div class="left-side-bar">
		<div class="brand-logo">
			<a href="index.html">
				<img src="<?php echo e(asset('dashboard/vendors/images/logo.png')); ?>" alt="" class="dark-logo">
				<img src="<?php echo e(asset('dashboard/vendors/images/logo-dark.png')); ?>" alt="" class="light-logo">
			</a>
			<div class="close-sidebar" data-toggle="left-sidebar-close">
				<i class="ion-close-round"></i>
			</div>
		</div>
		<div class="menu-block customscroll">
			<div class="sidebar-menu">
				<ul id="accordion-menu">
					<li>
							<a href="<?php echo e(url('home')); ?>" class="dropdown-toggle no-arrow">
								<span class="micon"> <i class=" fa fa-dashboard"></i></span><span class="mtext">Dashboard</span>
							</a>
						</li>
					<li class="dropdown">
						<a href="javascript:;" class="dropdown-toggle">
							<span class="micon"> <i class=" fa fa-envelope-open-o"></i></span><span class="mtext">SMS</span>
						</a>
						<ul class="submenu">
							<li><a href="<?php echo e(route('compose-sms')); ?>">Compose</a></li>
							<li><a href="<?php echo e(route('scheduled-sms')); ?>">Schedule</a></li>
							<li><a href="<?php echo e(route('sent-sms')); ?>">Sent</a></li>
							<li><a href="<?php echo e(route('draft')); ?>">Draft</a></li>
						</ul>
					</li>
					<li class="dropdown">
						<a href="javascript:;" class="dropdown-toggle">
							<span class="micon"> <i class=" fa fa-address-book-o"></i></span><span class="mtext">Contacts</span>
						</a>
						<ul class="submenu">
							<li><a href="<?php echo e(route('create-contact')); ?>">Add Contact</a></li>
							<li><a href="<?php echo e(route('contacts')); ?>">Manage Contacts</a></li>
						</ul>
					</li>
					<li class="dropdown">
						<a href="javascript:;" class="dropdown-toggle">
							<span class="micon"> <i class=" fa fa-money"></i></span><span class="mtext">Units/Credits</span>
						</a>
						<ul class="submenu">
							<li><a href="<?php echo e(route('buy-unit')); ?>">Buy Unit</a></li>
							<li><a href="<?php echo e(route('credits')); ?>">Purchase History</a></li>
						</ul>
					</li>
					
				</ul>
			</div>
		</div>
	</div><?php /**PATH C:\xampp\htdocs\sk\resources\views/layouts/dashboard/leftbar.blade.php ENDPATH**/ ?>