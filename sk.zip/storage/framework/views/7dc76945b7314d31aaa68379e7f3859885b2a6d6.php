
<?php $__env->startSection('title', 'Create Contact'); ?>
<?php $__env->startSection('content'); ?>


<div class="main-container">
	 <?php echo $__env->make('layouts.shared.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		<div class="pd-ltr-20 xs-pd-20-10">
			<div class="min-height-200px">
				<div class="page-header">
					<div class="row">
						<div class="col-md-6 col-sm-12">
							<div class="title">
								<h4>Contact List</h4>
							</div>
							<nav aria-label="breadcrumb" role="navigation">
								<ol class="breadcrumb">
									<li class="breadcrumb-item"><a href="index.html">Home</a></li>
									<li class="breadcrumb-item"><a href="<?php echo e(route('contacts')); ?>">Contacts</a></li>
									<li class="breadcrumb-item active" aria-current="page"><?php echo e($contact->title); ?></li>
								</ol>
							</nav>
						</div>
						
					</div>
				</div>
			<!-- Export Datatable start -->
				<div class="card-box mb-30">
					<div class="pd-20 row">
						<div class="col-md-2">
							<h4 class="text-blue h4"><?php echo e($contact->title); ?></h4>
						</div>
						
						<div class="text-right col-md-10">
							<button class="btn btn-sm" data-toggle="modal" data-target="#rename-modal">Rename <i class="fa fa-edit"></i></button>
							<button class="btn btn-sm" data-toggle="modal" data-target="#add-numbers">Add numbers <i class="fa fa-plus"></i></button>
						</div>
						<div class="col-12" id="alert-msg"></div>
						
					</div>
					<div class="pb-20 table-responsive">
						<table class="table hover multiple-select-row data-table-export nowrap table-hover">
							<thead>
								<tr>
									<th>S/N</th>
									<?php $__currentLoopData = $headRow; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $head): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<?php if(in_array(str_replace(' ','_',strtolower($head)), ['phone', 'phone_no', 'phone_number', 'phone_no.'])): ?>
										<?php $phoneField = $head ?>
										
									<?php endif; ?>

									<?php if(in_array(str_replace(' ','_',strtolower($head)), ['name', 'firstname', 'fullname', 'full_name', 'first_name'])): ?>
										<?php $nameField = $head ?>
										
									<?php endif; ?>
									<th> 
										<?php if(session('old_phone_column')): ?>
											<?php if(session('old_phone_column')==$head): ?>
												Phone
											<?php else: ?>
												<?php echo e($head); ?>

											<?php endif; ?>
										<?php else: ?>
											<?php echo e($head); ?>

										<?php endif; ?>
										<?php if(!session('old_phone_column')): ?>
											<?php if(!isset($phoneField)): ?> 
										 		<a href="javascript::void(0)"  data-toggle="modal" data-target="#rename-index-<?php echo e($index); ?>"><i class="fa fa-pencil"></i> </a> 
											<?php endif; ?>
										<?php else: ?>
											<?php if(!isset($nameField)): ?>
												<?php if(session('old_phone_column')!=$head): ?>
												
										 			<a href="javascript::void(0)"  data-toggle="modal" data-target="#point-name-index-<?php echo e($index); ?>"><i class="fa fa-pencil"></i> </a> 
										 		<?php endif; ?>
											<?php endif; ?>

										<?php endif; ?>
									</th>

									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</tr>
							</thead>
							<tbody>
								<?php $count = 0; ?>
								<?php $__currentLoopData = $bodyRow; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<?php $count ++ ?>
								
									<tr>
										<td><?php echo e($count); ?></td>
										<?php $__currentLoopData = $bodyRow[$key]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<td><?php echo e($data); ?></td>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										<th>
											<button class="btn btn-primary btn-sm" data-toggle="modal" data-target="#edit-<?php echo e($count); ?>">Edit <i class="fa fa-edit"></i></button>
											<button class="btn btn-danger btn-sm" data-toggle="modal" data-target="#delete-<?php echo e($count); ?>">Delete <i class="fa fa-trash"></i></button>
										</th> 
									</tr>
									<!--Edit Modal -->
									<div class="modal fade" id="edit-<?php echo e($count); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
									  <div class="modal-dialog modal-dialog-centered" role="document">
									    <div class="modal-content">
									    	<form class="form-control" action="<?php echo e(route('edit-number')); ?>" method="post">
									    		<?php echo csrf_field(); ?>
											      <div class="modal-header">
											        <h5 class="modal-title" id="exampleModalLongTitle">Edit Contact</h5>
											        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
											          <span aria-hidden="true">&times;</span>
											        </button>
											      </div>
											      <div class="modal-body">
											        	<input type="hidden" name="contact_id" value="<?php echo e($key); ?>">
											        	<input type="text" name="number" class="form-control" value="">
											        	<input type="hidden" name="old_number" value="">
											        
											      </div>
											      <div class="modal-footer">
											        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
											        <button type="" class="btn btn-primary">Save changes</button>
											      </div>
									      	</form>
									    </div>
									  </div>
									</div>
									<!--Edit Modal -->
									<div class="modal fade" id="delete-<?php echo e($count); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
									  <div class="modal-dialog modal-dialog-centered" role="document">
									    <div class="modal-content">
									    	<form  action="<?php echo e(route('delete-number')); ?>" method="post">
									    		<?php echo csrf_field(); ?>
											      <div class="modal-heade pt-3 row pr-1">
											      	<div class="col-11">
											      		<h6 class="text-center modal-title">Confirm action</h6>
											      	</div>
											      	<div class="col-1 text-left">
												      	<button type="button" class="close" data-dismiss="modal" aria-label="Close">
												          <span aria-hidden="true">&times;</span>
												        </button>
											      	</div>
											        

											        
											      </div>
											      <hr>
											      <div class="modal-bod text-center">
											      	Delete ?
											        	<input type="hidden" name="contact_id" value="<?php echo e($contact->id); ?>">
											        	<input type="hidden" name="number" class="form-control" value="">
											        	
											      </div>
											      <hr>
											      <div class="modal-foote text-center py-3">
											        <button type="button" class="btn btn-sm btn-secondary" data-dismiss="modal"><i class="fa fa-arrow-left"></i> Go back</button>
											        <button type="" class="btn btn-sm btn-primary">Proceed >></button>
											      </div>
									      	</form>
									    </div>
									  </div>
									</div>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</tbody>
						</table>

						
					</div>
				</div>
				<!-- Export Datatable End -->

				
				<!--Rename Modal -->
				<div class="modal fade" id="rename-modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
				  <div class="modal-dialog modal-dialog-centered" role="document">
				    <div class="modal-content">
				    	<form action="<?php echo e(route('rename-contact')); ?>" method="post">
				    		<?php echo csrf_field(); ?>
						      <div class="modal-header">
						        <h5 class="modal-title" id="exampleModalLongTitle">Rename Contact</h5>
						        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
						          <span aria-hidden="true">&times;</span>
						        </button>
						      </div>
						      <div class="modal-body">
						        	<input type="hidden" name="contact_slug" value="<?php echo e($contact->slug); ?>">
						        	<input type="text" name="title" class="form-control" value="<?php echo e($contact->title); ?>">
						        
						      </div>
						      <div class="modal-footer">
						        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
						        <button type="" class="btn btn-primary">Save changes</button>
						      </div>
				      	</form>
				    </div>
				  </div>

				</div>


				<!--Add Numbers Modal -->
				<div class="modal fade" id="add-numbers" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
				  <div class="modal-dialog modal-dialog-centered" role="document">
				    <div class="modal-content">
				    	<form action="<?php echo e(route('add-numbers-to-contact')); ?>" method="post">
				    		<?php echo csrf_field(); ?>
						      <div class="modal-header">
						        <h5 class="modal-title" id="exampleModalLongTitle">Add Numbers</h5>
						        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
						          <span aria-hidden="true">&times;</span>
						        </button>
						      </div>
						      <div class="modal-body">
						        	<input type="hidden" name="contact_slug" value="<?php echo e($contact->slug); ?>">
						        	<div class="form-group">
										<label class="col-form-label">Phone numbers</label>
										<small>(separate each phone number with a comma)</small>
										<input type="text" name="numbers" id="contact-input" class="form-control w-100" data-role="tagsinput">
										<?php $__errorArgs = ['numbers'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
											<span class="text-danger"><?php echo e($message); ?></span>
										<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
									</div>
						        
						      </div>
						      <div class="modal-footer">
						        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
						        <button type="" class="btn btn-primary">Save changes</button>
						      </div>
				      	</form>
				    </div>
				  </div>

				</div>
				<?php if(!session('old_phone_column')): ?>
					<?php if(!isset($phoneField)): ?>
						<script>
								$('#alert-msg').html('<div class="alert text-center alert-warning alert-dismissible fade show mt-3" role="alert" style="font-size: 14px;">No Column labelled as "Phone", "Phone Number", or "Phone no"  Please specify the phone number column by renaming it. </div>');
							</script>
					<?php endif; ?>
				<?php else: ?>
					<?php if(!isset($nameField)): ?>
						<script>
								$('#alert-msg').html('<div class="alert text-center alert-warning alert-dismissible fade show mt-3" role="alert" style="font-size: 14px;">No Column labelled as "Name", "Fullname", or "Firstname"  Please specify the name column by renaming it. <a href="<?php echo e(route('skip-name-column', $contact->slug)); ?>" class="text-primary">Skip this</a></div>');
							</script>
					<?php endif; ?>
				<?php endif; ?>

				<?php $__currentLoopData = $headRow; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=> $head): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

					<!--Rename column modal -->
					<div class="modal fade" id="rename-index-<?php echo e($index); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
					  <div class="modal-dialog modal-dialog-centered" role="document">
					    <div class="modal-content">
					    	<form action="<?php echo e(route('rename-contact-column')); ?>" method="post">
					    		<?php echo csrf_field(); ?>
							      <div class="modal-header">
							        <h5 class="modal-title" id="exampleModalLongTitle">Rename Column to "phone"</h5>
							        
							        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
							          <span aria-hidden="true">&times;</span>
							        </button>
							      </div>
							      <div class="modal-body">
							      	<p>Column will be renamed from "<?php echo e($head); ?>" to "Phone"</p>
							        	<input type="hidden" name="contact_slug" value="<?php echo e($contact->slug); ?>">
							        	<input type="hidden" name="old_name" value="<?php echo e($head); ?>">
							        	<input type="hidden" name="index" value="<?php echo e($index); ?>">
							        
							      </div>
							      <div class="modal-footer">
							        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
							        <button type="" class="btn btn-primary">Proceed >></button>
							      </div>
					      	</form>
					    </div>
					  </div>
					</div>


					<!--Indicate name column modal -->
					<div class="modal fade" id="point-name-index-<?php echo e($index); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
					  <div class="modal-dialog modal-dialog-centered" role="document">
					    <div class="modal-content">
					    	<form action="<?php echo e(route('rename-name-column')); ?>" method="post">
					    		<?php echo csrf_field(); ?>
							      <div class="modal-header">
							        <h5 class="modal-title" id="exampleModalLongTitle">Rename Column to "Name"</h5>
							        
							        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
							          <span aria-hidden="true">&times;</span>
							        </button>
							      </div>
							      <div class="modal-body">
							      	<p>Column will be renamed from "<?php echo e($head); ?>" to "Name"</p>
							        	<input type="hidden" name="contact_slug" value="<?php echo e($contact->slug); ?>">
							        	<input type="hidden" name="old_name" value="<?php echo e($head); ?>">
							        	<input type="hidden" name="index" value="<?php echo e($index); ?>">
							        
							      </div>
							      <div class="modal-footer">
							        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
							        <button type="" class="btn btn-primary">Proceed >></button>
							      </div>
					      	</form>
					    </div>
					  </div>
					</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sk\resources\views/contacts/detail_csv.blade.php ENDPATH**/ ?>