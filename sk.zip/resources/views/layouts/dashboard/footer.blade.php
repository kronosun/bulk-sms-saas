<div class="footer-wrap pd-20 mb-20 card-box">
		&copy;<script>document.write(new Date().getFullYear());</script> Powered By Skezzole. Template by <a href="https://github.com/dropways" target="_blank">Ankit Hingarajiya</a>
	</div>