<?php 
	namespace App\Custom;

	use Pnlinh\InfobipSms\Facades\InfobipSms;

	class SendMessage
	{

		public function sendMulti($array, $message){
	        $response = InfobipSms::send($array, $message);
	        return $response;
	    }

	}






 ?>