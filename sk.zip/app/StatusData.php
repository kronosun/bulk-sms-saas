<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class StatusData extends Model
{
     // public $table = 'status_data';
}
